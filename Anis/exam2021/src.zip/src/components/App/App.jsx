import React from "react";
import Navbar from "components/Navbar/Navbar";

const App = () => {
  return (
    <div>
      <Navbar />
    </div>
  );
};

export default App;
